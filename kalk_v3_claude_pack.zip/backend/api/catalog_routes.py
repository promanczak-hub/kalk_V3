"""API routes for Catalog Library (Biblioteka Cenników).

Endpoints under /api/catalogs/...
Manages global document sources (catalogs, price lists) per brand/model.
"""

from __future__ import annotations

import logging
import uuid
import anyio
from typing import Any, Optional

from fastapi import APIRouter, File, Form, HTTPException, UploadFile, BackgroundTasks
from pydantic import BaseModel

from core.database import supabase as sb_client
from core.cross_ref_llm import find_exact_variant_match

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/catalogs", tags=["catalogs"])

# ── Constants ────────────────────────────────────────────────────
_ALLOWED_FILE_TYPES = {"pdf", "xlsx", "csv"}
_STORAGE_BUCKET = "catalog-documents"
_SERVICE_ROLE_KEY = (
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
    ".eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0"
    ".EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU"
)


# ── Pydantic models ─────────────────────────────────────────────


class CatalogListItem(BaseModel):
    """Summary for catalog list view."""

    id: str
    brand: str
    model_family: str
    document_type: str
    display_name: str
    version_tag: Optional[str] = None
    is_active: bool
    file_type: str
    original_filename: Optional[str] = None
    extraction_status: str
    variant_count: int
    uploaded_at: str


class CatalogDetail(CatalogListItem):
    """Full catalog detail including extracted data."""

    extracted_data: Optional[dict[str, Any]] = None
    extraction_error: Optional[str] = None
    extracted_at: Optional[str] = None
    file_size_bytes: Optional[int] = None
    storage_path: str


# ── Helpers ──────────────────────────────────────────────────────


def _rs():
    """Shortcut for reverse_search schema client."""
    return sb_client.schema("reverse_search")


def _detect_file_type(filename: str) -> str:
    """Detect file type from filename extension."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext in _ALLOWED_FILE_TYPES:
        return ext
    raise ValueError(f"Unsupported file type: .{ext}")


# ── LIST ─────────────────────────────────────────────────────────


@router.get("")
def list_catalogs(
    brand: Optional[str] = None,
    model_family: Optional[str] = None,
    document_type: Optional[str] = None,
) -> dict[str, Any]:
    """List all catalogs with optional filters."""
    query = (
        _rs()
        .table("model_document_sources")
        .select(
            "id, brand, model_family, document_type, "
            "display_name, version_tag, is_active, file_type, "
            "original_filename, extraction_status, variant_count, "
            "uploaded_at"
        )
        .order("uploaded_at", desc=True)
    )

    if brand:
        query = query.ilike("brand", f"%{brand}%")
    if model_family:
        query = query.ilike("model_family", f"%{model_family}%")
    if document_type:
        query = query.eq("document_type", document_type)

    resp = query.execute()
    return {"catalogs": resp.data or [], "total": len(resp.data or [])}


@router.get("/match")
def match_catalogs_for_vehicle(vehicle_id: str) -> dict[str, Any]:
    """Fast brand-based catalog matching (no LLM).

    Returns all catalogs that match the vehicle's brand, sorted by
    model_family relevance. Much faster than /suggest (no LLM call).
    """
    v_resp = (
        sb_client.table("vehicle_synthesis")
        .select("synthesis_data")
        .eq("id", vehicle_id)
        .limit(1)
        .execute()
    )
    if not v_resp.data:
        raise HTTPException(404, f"Vehicle {vehicle_id} not found")

    synthesis = v_resp.data[0].get("synthesis_data") or {}
    card = synthesis.get("card_summary", {})
    brand = (card.get("brand") or synthesis.get("brand", "")).strip().upper()
    model = (card.get("model") or synthesis.get("model", "")).strip().lower()

    if not brand:
        return {"catalogs": []}

    c_resp = (
        _rs()
        .table("model_document_sources")
        .select(
            "id, brand, model_family, document_type, "
            "display_name, version_tag, file_type, "
            "extraction_status, variant_count, extracted_data"
        )
        .ilike("brand", f"%{brand}%")
        .order("uploaded_at", desc=True)
        .execute()
    )
    catalogs = c_resp.data or []

    vehicle_spec = {
        "brand": brand,
        "model": model,
        "body_style": card.get("body_style", ""),
        "powertrain": card.get("powertrain", ""),
        "power_hp": card.get("power_hp"),
        "drive_type": card.get("drive_type", ""),
        "transmission": card.get("transmission", ""),
        "vehicle_class": card.get("vehicle_class", ""),
        "trim_level": card.get("trim_level", ""),
        "base_price": card.get("base_price")
        or synthesis.get("pricing", {}).get("base_price"),
    }

    # Simple score: exact model match = 1.0, same brand = 0.5
    for cat in catalogs:
        cat_model = (cat.get("model_family") or "").strip().lower()
        base_score = 0.5
        if model and cat_model and model in cat_model:
            base_score = 1.0
        elif model and cat_model and cat_model in model:
            base_score = 0.9

        # Deep Match
        exact_variant = None
        extracted = cat.get("extracted_data") or {}
        if extracted:
            variants = extracted.get("variants", [])
            exact_variant = find_exact_variant_match(vehicle_spec, variants)

        # Obcięcie wyniku (kara) jeśli cena bazowa pojazdu istnieje, ale brak idealnego wariantu cenowego w cenniku
        has_base_price = bool(vehicle_spec.get("base_price"))
        if has_base_price and not exact_variant:
            base_score = min(base_score, 0.5)

        cat["score"] = base_score
        cat.pop("extracted_data", None)  # Usuń duży słownik przed wysłaniem

    catalogs.sort(key=lambda x: x.get("score", 0), reverse=True)
    return {"catalogs": catalogs}


@router.get("/suggest")
def suggest_catalogs(vehicle_id: str) -> dict[str, Any]:
    """Suggest best catalogs for a given vehicle using LLM ranking."""
    # 1. Fetch vehicle data
    v_resp = (
        sb_client.table("vehicle_synthesis")
        .select("synthesis_data")
        .eq("id", vehicle_id)
        .limit(1)
        .execute()
    )
    if not v_resp.data:
        raise HTTPException(404, f"Vehicle {vehicle_id} not found")

    synthesis = v_resp.data[0].get("synthesis_data") or {}
    card_summary = synthesis.get("card_summary", {})
    if not card_summary:
        raise HTTPException(400, "Vehicle has no card_summary")

    vehicle_spec = {
        "brand": card_summary.get("brand") or synthesis.get("brand", ""),
        "model": card_summary.get("model") or synthesis.get("model", ""),
        "body_style": card_summary.get("body_style", ""),
        "powertrain": card_summary.get("powertrain", ""),
        "power_hp": card_summary.get("power_hp"),
        "drive_type": card_summary.get("drive_type", ""),
        "transmission": card_summary.get("transmission", ""),
        "vehicle_class": card_summary.get("vehicle_class", ""),
        "trim_level": card_summary.get("trim_level", ""),
        "base_price": card_summary.get("base_price")
        or synthesis.get("pricing", {}).get("base_price"),
    }

    # 2. Fetch all ready textual catalogs
    c_resp = (
        _rs()
        .table("model_document_sources")
        .select(
            "id, brand, model_family, document_type, display_name, version_tag, file_type, extraction_status, variant_count, extracted_data"
        )
        .eq("extraction_status", "ready")
        .order("uploaded_at", desc=True)
        .execute()
    )
    catalogs = c_resp.data or []

    if not catalogs:
        return {"catalogs": []}

    # 3. Use LLM to rank catalogs
    from core.feature_cross_reference import rank_catalogs_for_vehicle

    ranked_catalogs = rank_catalogs_for_vehicle(vehicle_spec, catalogs)

    return {"catalogs": ranked_catalogs}


# ── GET DETAIL ───────────────────────────────────────────────────


@router.get("/{catalog_id}")
def get_catalog_detail(catalog_id: str) -> dict[str, Any]:
    """Get full catalog detail including extracted data."""
    resp = (
        _rs().table("model_document_sources").select("*").eq("id", catalog_id).execute()
    )
    if not resp.data:
        raise HTTPException(404, "Catalog not found")
    return {"catalog": resp.data[0]}


# ── UPLOAD ───────────────────────────────────────────────────────


@router.post("/upload")
async def upload_catalog(
    file: UploadFile = File(...),
    brand: str = Form(...),
    model_family: str = Form(...),
    document_type: str = Form(...),
    display_name: str = Form(...),
    version_tag: Optional[str] = Form(None),
) -> dict[str, Any]:
    """Upload a catalog/price list file and store metadata."""
    # Validate
    _VALID_DOC_TYPES = {"catalog", "price_list", "brochure", "other"}
    if document_type not in _VALID_DOC_TYPES:
        raise HTTPException(
            400,
            f"document_type must be one of: {', '.join(sorted(_VALID_DOC_TYPES))}",
        )

    filename = file.filename or "unknown"
    try:
        file_type = _detect_file_type(filename)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

    # Read file content
    content = await file.read()
    file_size = len(content)

    # Upload to Supabase Storage
    doc_id = str(uuid.uuid4())
    storage_path = f"{brand}/{model_family}/{doc_id}.{file_type}"

    try:
        await anyio.to_thread.run_sync(
            sb_client.storage.from_(_STORAGE_BUCKET).upload,
            storage_path,
            content,
            {"content-type": file.content_type or "application/octet-stream"},
        )
    except Exception as exc:
        logger.error("Storage upload failed: %s", exc)
        raise HTTPException(500, f"File upload failed: {exc}") from exc

    # Insert metadata
    row = {
        "id": doc_id,
        "brand": brand.strip(),
        "model_family": model_family.strip(),
        "document_type": document_type,
        "display_name": display_name.strip(),
        "version_tag": version_tag.strip() if version_tag else None,
        "is_active": True,
        "file_type": file_type,
        "storage_path": storage_path,
        "original_filename": filename,
        "file_size_bytes": file_size,
        "extraction_status": "pending",
        "variant_count": 0,
    }

    try:
        resp = _rs().table("model_document_sources").insert(row).execute()
    except Exception as exc:
        logger.error("DB insert failed: %s", exc)
        raise HTTPException(500, f"Metadata insert failed: {exc}") from exc

    logger.info(
        "Uploaded catalog: %s (%s/%s) → %s",
        display_name,
        brand,
        model_family,
        storage_path,
    )

    return {"status": "uploaded", "catalog": resp.data[0] if resp.data else row}


# ── MARKDOWN PREVIEW ────────────────────────────────────────────


@router.get("/{catalog_id}/markdown")
def get_catalog_markdown(catalog_id: str) -> dict[str, Any]:
    """Fetch the raw docling markdown for a catalog document."""
    resp = (
        _rs()
        .table("model_document_sources")
        .select("document_markdown")
        .eq("id", catalog_id)
        .execute()
    )
    if not resp.data:
        raise HTTPException(404, "Catalog not found")
    return {"markdown": resp.data[0].get("document_markdown") or ""}


# ── FILE DOWNLOAD / PREVIEW ─────────────────────────────────────


@router.get("/{catalog_id}/file")
async def get_catalog_file(catalog_id: str):
    """Download the original catalog file for preview."""
    resp = (
        _rs()
        .table("model_document_sources")
        .select("storage_path, file_type, original_filename")
        .eq("id", catalog_id)
        .execute()
    )
    if not resp.data:
        raise HTTPException(404, "Catalog not found")

    row = resp.data[0]
    storage_path = row["storage_path"]

    from urllib.parse import quote

    try:
        encoded_path = quote(storage_path, safe="/")
        file_bytes = await anyio.to_thread.run_sync(
            sb_client.storage.from_(_STORAGE_BUCKET).download, encoded_path
        )
    except Exception as exc:
        exc_str = str(exc)
        if "404" in exc_str or "Object not found" in exc_str:
            raise HTTPException(
                404,
                f"Plik fizycznie nie istnieje w magazynie danych (Storage): {storage_path}",
            ) from exc
        raise HTTPException(500, f"File download failed: {exc}") from exc

    from fastapi.responses import Response

    content_type_map = {
        "pdf": "application/pdf",
        "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "csv": "text/csv",
    }
    content_type = content_type_map.get(row["file_type"], "application/octet-stream")
    filename = row.get("original_filename") or f"catalog.{row['file_type']}"

    return Response(
        content=file_bytes,
        media_type=content_type,
        headers={"Content-Disposition": f'inline; filename="{filename}"'},
    )


# ── XLSX DATA (for full viewer) ──────────────────────────────────


@router.get("/{catalog_id}/xlsx-data")
async def get_catalog_xlsx_data(catalog_id: str) -> dict[str, Any]:
    """Parse XLSX and return sheet data for frontend viewer.

    Returns all sheets with cell values, styles (colors), and metadata.
    """
    resp = (
        _rs()
        .table("model_document_sources")
        .select("storage_path, file_type")
        .eq("id", catalog_id)
        .execute()
    )
    if not resp.data:
        raise HTTPException(404, "Catalog not found")

    row = resp.data[0]
    if row["file_type"] != "xlsx":
        raise HTTPException(400, "Only XLSX files can be previewed as spreadsheet")

    from urllib.parse import quote

    try:
        encoded_path = quote(row["storage_path"], safe="/")
        file_bytes = await anyio.to_thread.run_sync(
            sb_client.storage.from_(_STORAGE_BUCKET).download, encoded_path
        )
    except Exception as exc:
        exc_str = str(exc)
        if "404" in exc_str or "Object not found" in exc_str:
            raise HTTPException(
                404,
                f"Plik fizycznie nie istnieje w magazynie danych (Storage): {row['storage_path']}",
            ) from exc
        raise HTTPException(500, f"File download failed: {exc}") from exc

    from core.catalog_xlsx_parser import parse_xlsx_for_viewer

    sheets = parse_xlsx_for_viewer(file_bytes)
    return {"sheets": sheets}


# ── TRIGGER EXTRACTION ───────────────────────────────────────────


@router.post("/{catalog_id}/extract")
def trigger_extraction(catalog_id: str) -> dict[str, Any]:
    """Trigger AI extraction of variants from catalog document."""
    resp = (
        _rs().table("model_document_sources").select("*").eq("id", catalog_id).execute()
    )
    if not resp.data:
        raise HTTPException(404, "Catalog not found")

    catalog = resp.data[0]

    if catalog["extraction_status"] == "extracting":
        raise HTTPException(409, "Extraction already in progress")

    # Mark as extracting
    _rs().table("model_document_sources").update(
        {"extraction_status": "extracting"}
    ).eq("id", catalog_id).execute()

    # Zamiast threading używamy workera Celery
    from core.celery_tasks import extract_catalog_task

    extract_catalog_task.delay(catalog_id)

    return {"status": "extraction_started", "catalog_id": catalog_id}


# ── REPROCESS AS OFFER ──────────────────────────────────────────


@router.post("/{catalog_id}/reprocess")
def reprocess_catalog_as_offer(
    catalog_id: str, background_tasks: BackgroundTasks
) -> dict[str, Any]:
    """Reprocess a catalog document as an OFFER."""
    resp = (
        _rs()
        .table("model_document_sources")
        .select("storage_path, original_filename, file_type")
        .eq("id", catalog_id)
        .execute()
    )
    if not resp.data:
        raise HTTPException(404, "Catalog not found")

    row = resp.data[0]
    storage_path = row["storage_path"]
    filename = row.get("original_filename") or f"document.{row['file_type']}"

    # Pusta suma kontrolna na etapie API, celowo - worker obliczy na pobranym pliku, ale tutaj by wystartować wstrzykujemy ""
    md5_hash = ""

    content_type_map = {
        "pdf": "application/pdf",
        "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "csv": "text/csv",
    }
    mime_type = content_type_map.get(row["file_type"], "application/octet-stream")

    from core.celery_tasks import process_document_task_from_storage

    # We create a new synthesis row for the file upload (like the regular upload does)
    new_id = str(uuid.uuid4())
    sb_client.table("vehicle_synthesis").insert(
        {"id": new_id, "verification_status": "processing", "file_hash": md5_hash}
    ).execute()

    process_document_task_from_storage.delay(
        file_id=new_id,
        storage_path=storage_path,
        bucket_name=_STORAGE_BUCKET,
        file_name=filename,
        mime_type=mime_type,
        md5_hash=md5_hash,
        force_doc_type="OFFER",  # Force processing as OFFER
    )

    # Optional: Delete the original from model_document_sources
    # Delete from DB (cascade deletes vehicle_catalog_matches)
    _rs().table("model_document_sources").delete().eq("id", catalog_id).execute()
    from urllib.parse import quote

    try:
        encoded_path = quote(storage_path, safe="/")
        sb_client.storage.from_(_STORAGE_BUCKET).remove([encoded_path])
    except Exception as exc:
        logger.warning("Storage delete failed (continuing): %s", exc)

    return {
        "status": "processing",
        "vehicle_id": new_id,
        "message": "Rozpoczęto przetwarzanie jako Oferta w tle (Celery).",
    }


# ── ACTIVATE / DEACTIVATE ───────────────────────────────────────


@router.patch("/{catalog_id}/activate")
def toggle_catalog_active(
    catalog_id: str,
    is_active: bool = True,
) -> dict[str, Any]:
    """Set a catalog version as active or inactive."""
    resp = (
        _rs()
        .table("model_document_sources")
        .update({"is_active": is_active})
        .eq("id", catalog_id)
        .execute()
    )
    if not resp.data:
        raise HTTPException(404, "Catalog not found")
    return {"status": "updated", "catalog": resp.data[0]}


# ── DELETE ───────────────────────────────────────────────────────


@router.delete("/{catalog_id}")
def delete_catalog(catalog_id: str) -> dict[str, Any]:
    """Delete a catalog and its file from storage."""
    resp = (
        _rs()
        .table("model_document_sources")
        .select("storage_path")
        .eq("id", catalog_id)
        .execute()
    )
    if not resp.data:
        raise HTTPException(404, "Catalog not found")

    storage_path = resp.data[0]["storage_path"]

    from urllib.parse import quote

    # Delete from storage
    try:
        encoded_path = quote(storage_path, safe="/")
        sb_client.storage.from_(_STORAGE_BUCKET).remove([encoded_path])
    except Exception as exc:
        logger.warning("Storage delete failed (continuing): %s", exc)

    # Delete from DB (cascade deletes vehicle_catalog_matches)
    _rs().table("model_document_sources").delete().eq("id", catalog_id).execute()

    return {"status": "deleted", "catalog_id": catalog_id}
